$(document).ready(function() {

  $("#bid_deliverytype").change(SetFieldsVisibility);
  $("#bid_deliverytype").change();
});

function SetFieldsVisibility() {
  var selectedValue = $("#bid_deliverytype").val();
    $("#bid_transportfeepipeline").closest("tr").show();
    $("#bid_transportfeefuelsurcharge").closest("tr").show();
    $("#bid_transportfeetruck").closest("tr").show();
    $("#bid_fuelsupplyterminal").closest("td").show();
    $("#bid_fuelsupplypipeline").closest("td").show();

  //Into-Storage Truck
  if (selectedValue == "757570000" )
  {
    $("#bid_transportfeepipeline").closest("tr").hide();
    $("#bid_fuelsupplypipeline").closest("td").hide();

  }
  //Into-Storage Pipe
    if (selectedValue == "757570001" )
  {
    $("#bid_transportfeefuelsurcharge").closest("tr").hide();
    $("#bid_transportfeetruck").closest("tr").hide();
    $("#bid_fuelsupplyterminal").closest("td").hide();
  }
  //Into-Storage Barge or Into-Pipe
    if (selectedValue == "757570002" || selectedValue == "757570004")
  {
    $("#bid_transportfeefuelsurcharge").closest("tr").hide();
    $("#bid_transportfeetruck").closest("tr").hide();
    $("#bid_transportfeepipeline").closest("tr").hide();
    $("#bid_fuelsupplyterminal").closest("td").hide();
    $("#bid_fuelsupplypipeline").closest("td").hide();
  }
  //Truck Rack
    if (selectedValue == "757570005" )
  {
    $("#bid_transportfeefuelsurcharge").closest("tr").hide();
    $("#bid_transportfeetruck").closest("tr").hide();
    $("#bid_fuelsupplyterminal").closest("td").hide();
  }
}